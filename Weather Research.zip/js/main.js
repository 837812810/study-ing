var app = new Vue({
    el: "#app",
    data: {
        city: '',
    },
    methods: {
        searchweather: function () {
            axios.get('http://wthrcdn.etouch.cn/weather_mini?city=' + this.city)
                .then(function (response) {
                    console.log(response);
                })
                .catch(function (err) { })
        }
    }
})